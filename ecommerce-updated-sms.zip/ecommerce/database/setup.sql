-- ========================================
-- E-Commerce Database Setup (SQL Server)
-- Updated with Payment, Tracking, Delivery
-- ========================================

IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = 'EcommerceDB')
BEGIN
    CREATE DATABASE EcommerceDB;
END
GO

USE EcommerceDB;
GO

-- Products table
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Products' AND xtype='U')
BEGIN
    CREATE TABLE Products (
        Id          INT IDENTITY(1,1) PRIMARY KEY,
        Name        NVARCHAR(200)  NOT NULL,
        Category    NVARCHAR(100)  NOT NULL,
        Price       DECIMAL(10,2)  NOT NULL,
        Stock       INT            NOT NULL DEFAULT 0,
        Description NVARCHAR(500),
        Emoji       NVARCHAR(10)   DEFAULT N'📦',
        CreatedAt   DATETIME       DEFAULT GETDATE()
    );
END
GO

-- DeliveryPersons table
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='DeliveryPersons' AND xtype='U')
BEGIN
    CREATE TABLE DeliveryPersons (
        Id        INT IDENTITY(1,1) PRIMARY KEY,
        Name      NVARCHAR(200) NOT NULL,
        Phone     NVARCHAR(20)  NOT NULL,
        NID       NVARCHAR(30),
        Vehicle   NVARCHAR(100),
        Photo     NVARCHAR(10)  DEFAULT N'🛵',
        IsActive  BIT           DEFAULT 1
    );
END
GO

-- Orders table
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Orders' AND xtype='U')
BEGIN
    CREATE TABLE Orders (
        Id               INT IDENTITY(1,1) PRIMARY KEY,
        CustomerName     NVARCHAR(200) NOT NULL,
        Phone            NVARCHAR(20)  NOT NULL,
        Address          NVARCHAR(500) NOT NULL,
        City             NVARCHAR(100),
        PostalCode       NVARCHAR(20),
        SubTotal         DECIMAL(10,2) NOT NULL DEFAULT 0,
        DeliveryCharge   DECIMAL(10,2) NOT NULL DEFAULT 0,
        TotalAmount      DECIMAL(10,2) NOT NULL,
        PaymentMethod    NVARCHAR(50)  DEFAULT 'COD',
        PaymentStatus    NVARCHAR(50)  DEFAULT 'Pending',
        TransactionId    NVARCHAR(200),
        PaymentPhone     NVARCHAR(20),
        Status           NVARCHAR(50)  DEFAULT 'Pending',
        DeliveryPersonId INT FOREIGN KEY REFERENCES DeliveryPersons(Id),
        EstimatedDelivery DATE,
        DeliveryNote     NVARCHAR(500),
        CreatedAt        DATETIME      DEFAULT GETDATE(),
        UpdatedAt        DATETIME      DEFAULT GETDATE()
    );
END
GO

-- OrderItems table
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='OrderItems' AND xtype='U')
BEGIN
    CREATE TABLE OrderItems (
        Id        INT IDENTITY(1,1) PRIMARY KEY,
        OrderId   INT NOT NULL FOREIGN KEY REFERENCES Orders(Id),
        ProductId INT NOT NULL FOREIGN KEY REFERENCES Products(Id),
        Quantity  INT NOT NULL,
        Price     DECIMAL(10,2) NOT NULL
    );
END
GO

-- OrderTracking table
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='OrderTracking' AND xtype='U')
BEGIN
    CREATE TABLE OrderTracking (
        Id          INT IDENTITY(1,1) PRIMARY KEY,
        OrderId     INT NOT NULL FOREIGN KEY REFERENCES Orders(Id),
        Status      NVARCHAR(50)  NOT NULL,
        Message     NVARCHAR(500),
        CreatedAt   DATETIME      DEFAULT GETDATE()
    );
END
GO

-- Notifications table
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Notifications' AND xtype='U')
BEGIN
    CREATE TABLE Notifications (
        Id        INT IDENTITY(1,1) PRIMARY KEY,
        OrderId   INT NOT NULL FOREIGN KEY REFERENCES Orders(Id),
        Type      NVARCHAR(50),
        Phone     NVARCHAR(20),
        Message   NVARCHAR(500),
        SentAt    DATETIME DEFAULT GETDATE()
    );
END
GO

-- DeliveryCharges table
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='DeliveryCharges' AND xtype='U')
BEGIN
    CREATE TABLE DeliveryCharges (
        Id     INT IDENTITY(1,1) PRIMARY KEY,
        City   NVARCHAR(100) NOT NULL,
        Charge DECIMAL(10,2) NOT NULL
    );
END
GO

-- ── পুরনো database এর জন্য Missing Columns Fix ──────────────

IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Orders') AND name = 'City')
    ALTER TABLE Orders ADD City NVARCHAR(100) NULL;
GO
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Orders') AND name = 'PostalCode')
    ALTER TABLE Orders ADD PostalCode NVARCHAR(20) NULL;
GO
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Orders') AND name = 'SubTotal')
    ALTER TABLE Orders ADD SubTotal DECIMAL(10,2) NULL DEFAULT 0;
GO
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Orders') AND name = 'DeliveryCharge')
    ALTER TABLE Orders ADD DeliveryCharge DECIMAL(10,2) NULL DEFAULT 0;
GO
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Orders') AND name = 'PaymentMethod')
    ALTER TABLE Orders ADD PaymentMethod NVARCHAR(50) NULL DEFAULT 'COD';
GO
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Orders') AND name = 'PaymentStatus')
    ALTER TABLE Orders ADD PaymentStatus NVARCHAR(50) NULL DEFAULT 'Pending';
GO
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Orders') AND name = 'TransactionId')
    ALTER TABLE Orders ADD TransactionId NVARCHAR(200) NULL;
GO
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Orders') AND name = 'PaymentPhone')
    ALTER TABLE Orders ADD PaymentPhone NVARCHAR(20) NULL;
GO
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Orders') AND name = 'DeliveryPersonId')
    ALTER TABLE Orders ADD DeliveryPersonId INT NULL;
GO
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Orders') AND name = 'EstimatedDelivery')
    ALTER TABLE Orders ADD EstimatedDelivery DATE NULL;
GO
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Orders') AND name = 'DeliveryNote')
    ALTER TABLE Orders ADD DeliveryNote NVARCHAR(500) NULL;
GO
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Orders') AND name = 'UpdatedAt')
    ALTER TABLE Orders ADD UpdatedAt DATETIME NULL DEFAULT GETDATE();
GO

-- ── Sample Data (শুধু খালি থাকলে insert হবে) ───────────────

IF NOT EXISTS (SELECT TOP 1 1 FROM Products)
BEGIN
    INSERT INTO Products (Name, Category, Price, Stock, Emoji) VALUES
    (N'Wireless Earbuds',  N'Electronics', 1200.00, 50,  N'🎧'),
    (N'Smart Watch',       N'Electronics', 2500.00, 30,  N'⌚'),
    (N'Phone Stand',       N'Electronics',  350.00, 100, N'📱'),
    (N'USB Hub',           N'Electronics',  800.00, 40,  N'💻'),
    (N'Panjabi (White)',   N'Fashion',       950.00, 60,  N'👕'),
    (N'Saree',             N'Fashion',      1800.00, 25,  N'👗'),
    (N'Sneakers',          N'Fashion',      1500.00, 35,  N'👟'),
    (N'Hilsa Fish 1kg',    N'Food',          750.00, 20,  N'🐟'),
    (N'Mishti Doi',        N'Food',          120.00, 80,  N'🍮'),
    (N'Bamboo Chair',      N'Home',         2200.00, 15,  N'🪑'),
    (N'Table Lamp',        N'Home',          680.00, 45,  N'💡'),
    (N'Wall Clock',        N'Home',          450.00, 55,  N'🕐');
END
GO

IF NOT EXISTS (SELECT TOP 1 1 FROM DeliveryPersons)
BEGIN
    INSERT INTO DeliveryPersons (Name, Phone, NID, Vehicle, Photo) VALUES
    (N'রাহুল মিয়া',  '01711111111', '198012345678', N'মোটরসাইকেল', N'🛵'),
    (N'করিম শেখ',   '01822222222', '199087654321', N'বাইসাইকেল',   N'🚴'),
    (N'সুজন আহমেদ', '01933333333', '198567891234', N'মোটরসাইকেল', N'🛵');
END
GO

IF NOT EXISTS (SELECT TOP 1 1 FROM DeliveryCharges)
BEGIN
    INSERT INTO DeliveryCharges (City, Charge) VALUES
    (N'ঢাকা',       60.00),
    (N'চট্টগ্রাম',  120.00),
    (N'সিলেট',      130.00),
    (N'রাজশাহী',    130.00),
    (N'খুলনা',      130.00),
    (N'বরিশাল',     140.00),
    (N'ময়মনসিংহ',  110.00),
    (N'রংপুর',      140.00),
    (N'কুমিল্লা',   100.00),
    (N'নারায়ণগঞ্জ', 80.00),
    (N'গাজীপুর',     80.00),
    (N'অন্যান্য',   150.00);
END
GO

PRINT '✅ Database setup complete! All columns verified.';

SELECT * FROM Orders ORDER BY CreatedAt DESC;