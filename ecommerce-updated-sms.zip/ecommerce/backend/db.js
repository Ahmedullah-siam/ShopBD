const sql = require('mssql');

const config = {
    server: 'localhost\\SQLEXPRESS',
    database: 'EcommerceDB',
    user: 'sa',
    password: 'Shop1234!',
    options: {
        trustServerCertificate: true,
        encrypt: false
    }
};

const poolPromise = new sql.ConnectionPool(config)
    .connect()
    .then(pool => {
        console.log('✅ SQL Server connected!');
        return pool;
    })
    .catch(err => {
        console.error('❌ SQL Server connection failed:', err.message);
        process.exit(1);
    });

module.exports = { sql, poolPromise };