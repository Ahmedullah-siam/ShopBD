const express = require('express');
const router = express.Router();
const { sql, poolPromise } = require('../db');
const nodemailer = require('nodemailer');
const https = require('https');

// ══════════════════════════════════════════════════════════════
// SMS CONFIG — Green Web Bangladesh SMS Gateway
// ══════════════════════════════════════════════════════════════
// 👉 greenweb.com.bd থেকে account খুলে নিচের credentials দিন
const GREENWEB_TOKEN = 'YOUR_GREENWEB_TOKEN';   // API token (Dashboard > Profile > API Token)
const GREENWEB_SID   = 'YOUR_GREENWEB_SID';     // Sender ID (e.g. 'ShopBD' — approve করাতে হয়)

// Token placeholder হলে SMS skip হবে — server crash হবে না
const smsConfigured = (GREENWEB_TOKEN !== 'YOUR_GREENWEB_TOKEN');

// ── Gmail Email config ────────────────────────────────────────
const GMAIL_USER = 'YOUR_GMAIL@gmail.com';
const GMAIL_PASS = 'YOUR_APP_PASSWORD';

const transporter = (GMAIL_USER !== 'YOUR_GMAIL@gmail.com' && GMAIL_PASS !== 'YOUR_APP_PASSWORD')
    ? nodemailer.createTransport({
        service: 'gmail',
        auth: { user: GMAIL_USER, pass: GMAIL_PASS }
    })
    : null;

// ── Send SMS via Green Web ─────────────────────────────────────
async function sendSMS(to, message) {
    if (!smsConfigured) {
        console.log('⚠️  SMS skip করা হয়েছে (Green Web configure করা নেই)');
        console.log(`📱 SMS to ${to}: ${message}`);
        return;
    }

    // Bangladesh number format: 01XXXXXXXXX → 8801XXXXXXXXX
    let phone = to.replace(/^\+/, '').replace(/^880/, '').replace(/^0/, '');
    phone = '880' + phone;

    const params = new URLSearchParams({
        token:  GREENWEB_TOKEN,
        to:     phone,
        message: message,
        sid:    GREENWEB_SID
    });

    return new Promise((resolve) => {
        const url = `https://api.greenweb.com.bd/api.php?${params.toString()}`;
        https.get(url, (res) => {
            let data = '';
            res.on('data', chunk => data += chunk);
            res.on('end', () => {
                if (data.startsWith('200')) {
                    console.log('✅ SMS পাঠানো হয়েছে:', to);
                } else {
                    console.error('❌ SMS error (Green Web):', data);
                }
                resolve();
            });
        }).on('error', (err) => {
            console.error('❌ SMS network error:', err.message);
            resolve();
        });
    });
}

// ── Send Email ────────────────────────────────────────────────
async function sendEmail(to, subject, html) {
    if (!transporter) {
        console.log('⚠️ Email skip করা হয়েছে (Gmail configure করা নেই)');
        return;
    }
    try {
        await transporter.sendMail({
            from: `"ShopBD" <${GMAIL_USER}>`,
            to,
            subject,
            html
        });
        console.log('✅ Email পাঠানো হয়েছে:', to);
    } catch (err) {
        console.error('❌ Email error:', err.message);
    }
}
 
// ── Email template ────────────────────────────────────────────
function orderEmailTemplate(title, orderId, customerName, items, subTotal, deliveryCharge, total, payMethod, status, extraMsg) {
    return `
    <div style="font-family:Arial,sans-serif;max-width:600px;margin:auto;border:1px solid #eee;border-radius:10px;overflow:hidden">
        <div style="background:#6c63ff;padding:20px;text-align:center">
            <h1 style="color:#fff;margin:0">🛍️ ShopBD</h1>
        </div>
        <div style="padding:24px">
            <h2 style="color:#333">${title}</h2>
            <p style="color:#555">প্রিয় <strong>${customerName}</strong>,</p>
            <p style="color:#555">${extraMsg}</p>
            <div style="background:#f8f9ff;border-radius:8px;padding:16px;margin:16px 0">
                <p style="margin:0 0 8px"><strong>অর্ডার ID:</strong> #${orderId}</p>
                <p style="margin:0 0 8px"><strong>Status:</strong> ${status}</p>
                <p style="margin:0 0 8px"><strong>Payment:</strong> ${payMethod}</p>
                <hr style="border:none;border-top:1px dashed #ccc;margin:12px 0">
                <p style="margin:0 0 4px"><strong>পণ্য মূল্য:</strong> ৳${subTotal}</p>
                <p style="margin:0 0 4px"><strong>ডেলিভারি:</strong> ৳${deliveryCharge}</p>
                <p style="margin:0;font-size:18px;color:#6c63ff"><strong>মোট: ৳${total}</strong></p>
            </div>
            <p style="color:#888;font-size:13px">ধন্যবাদ ShopBD তে কেনাকাটা করার জন্য!</p>
        </div>
        <div style="background:#f1f1f1;padding:12px;text-align:center">
            <p style="margin:0;font-size:12px;color:#999">ShopBD — Bangladesh এর সেরা Online Shop</p>
        </div>
    </div>`;
}
 
// ── Owner payment details ─────────────────────────────────────
const OWNER_BKASH_NUMBER  = '01771484565';
const OWNER_NAGAD_NUMBER  = '01771484565';
const OWNER_BANK_ACCOUNT  = '0017031057767';

// ── POST /api/orders/send-otp — OTP পাঠানো ────────────────────
router.post('/send-otp', async (req, res) => {
    const { phone, otp, method } = req.body;
    if (!phone || !otp) return res.status(400).json({ error: 'phone and otp required' });

    const msg = `ShopBD: আপনার ${method || 'পেমেন্ট'} OTP হলো: ${otp}। কাউকে জানাবেন না।`;
    await sendSMS(phone, msg);
    console.log(`OTP for ${phone}: ${otp}`);   // dev log
    res.json({ sent: true });
});

// ── GET /api/orders/payment-info — owner payment details ──────
router.get('/payment-info', (req, res) => {
    res.json({
        bkash:  OWNER_BKASH_NUMBER,
        nagad:  OWNER_NAGAD_NUMBER,
        bank:   OWNER_BANK_ACCOUNT
    });
});


router.get('/delivery-charge', async (req, res) => {
    const { city } = req.query;
    try {
        const pool = await poolPromise;
        let result = await pool.request()
            .input('city', sql.NVarChar, city)
            .query("SELECT Charge FROM DeliveryCharges WHERE City=@city");
        if (!result.recordset.length) {
            result = await pool.request()
                .query("SELECT Charge FROM DeliveryCharges WHERE City=N'অন্যান্য'");
        }
        const charge = result.recordset[0]?.Charge || 150;
        res.json({ charge });
    } catch (err) {
        res.json({ charge: 150 });
    }
});
 
// ── POST /api/orders — নতুন order ────────────────────────────
router.post('/', async (req, res) => {
    const {
        CustomerName, Phone, Address, City, PostalCode, items,
        PaymentMethod, TransactionId, PaymentPhone,
        CustomerEmail   // optional email field
    } = req.body;
 
    if (!CustomerName || !Phone || !Address || !items?.length) {
        return res.status(400).json({ error: 'Missing required fields' });
    }
 
    try {
        const pool = await poolPromise;
 
        // SubTotal calculate
        let subTotal = 0;
        for (const item of items) {
            const p = await pool.request()
                .input('id', sql.Int, item.productId)
                .query('SELECT Price FROM Products WHERE Id=@id');
            if (p.recordset[0]) subTotal += p.recordset[0].Price * item.quantity;
        }
 
        // Delivery charge
        let dcResult = await pool.request()
            .input('city', sql.NVarChar, City || '')
            .query("SELECT Charge FROM DeliveryCharges WHERE City=@city");
        if (!dcResult.recordset.length) {
            dcResult = await pool.request()
                .query("SELECT Charge FROM DeliveryCharges WHERE City=N'অন্যান্য'");
        }
        const deliveryCharge = dcResult.recordset[0]?.Charge || 150;
        const total = subTotal + deliveryCharge;
        const paymentStatus = (PaymentMethod === 'COD') ? 'Pending' : 'Paid';
        const estimated = new Date();
        estimated.setDate(estimated.getDate() + 3);
 
        // Insert Order
        const orderResult = await pool.request()
            .input('CustomerName',   sql.NVarChar,  CustomerName)
            .input('Phone',          sql.NVarChar,  Phone)
            .input('Address',        sql.NVarChar,  Address)
            .input('City',           sql.NVarChar,  City || '')
            .input('PostalCode',     sql.NVarChar,  PostalCode || '')
            .input('SubTotal',       sql.Decimal,   subTotal)
            .input('DeliveryCharge', sql.Decimal,   deliveryCharge)
            .input('TotalAmount',    sql.Decimal,   total)
            .input('PaymentMethod',  sql.NVarChar,  PaymentMethod || 'COD')
            .input('PaymentStatus',  sql.NVarChar,  paymentStatus)
            .input('TransactionId',  sql.NVarChar,  TransactionId || null)
            .input('PaymentPhone',   sql.NVarChar,  PaymentPhone || null)
            .input('EstimatedDelivery', sql.Date,   estimated)
            .query(`
                INSERT INTO Orders
                    (CustomerName,Phone,Address,City,PostalCode,
                     SubTotal,DeliveryCharge,TotalAmount,
                     PaymentMethod,PaymentStatus,TransactionId,PaymentPhone,
                     Status,EstimatedDelivery)
                OUTPUT INSERTED.Id
                VALUES
                    (@CustomerName,@Phone,@Address,@City,@PostalCode,
                     @SubTotal,@DeliveryCharge,@TotalAmount,
                     @PaymentMethod,@PaymentStatus,@TransactionId,@PaymentPhone,
                     'Pending',@EstimatedDelivery)
            `);
 
        const orderId = orderResult.recordset[0].Id;
 
        // Insert OrderItems
        for (const item of items) {
            const p = await pool.request()
                .input('id', sql.Int, item.productId)
                .query('SELECT Price FROM Products WHERE Id=@id');
            const price = p.recordset[0]?.Price || 0;
            await pool.request()
                .input('OrderId',   sql.Int,     orderId)
                .input('ProductId', sql.Int,     item.productId)
                .input('Quantity',  sql.Int,     item.quantity)
                .input('Price',     sql.Decimal, price)
                .query('INSERT INTO OrderItems (OrderId,ProductId,Quantity,Price) VALUES (@OrderId,@ProductId,@Quantity,@Price)');
        }
 
        // Insert tracking
        await pool.request()
            .input('OrderId', sql.Int,     orderId)
            .input('Status',  sql.NVarChar, 'Pending')
            .input('Message', sql.NVarChar, 'আপনার অর্ডার গ্রহণ করা হয়েছে। শীঘ্রই কনফার্ম করা হবে।')
            .query('INSERT INTO OrderTracking (OrderId,Status,Message) VALUES (@OrderId,@Status,@Message)');
 
        // Log notification
        const smsMsg   = `ShopBD: আপনার অর্ডার #${orderId} সফলভাবে দেওয়া হয়েছে। মোট: ৳${Math.round(total)}। ধন্যবাদ!`;
        await pool.request()
            .input('OrderId', sql.Int,     orderId)
            .input('Type',    sql.NVarChar, 'order_placed')
            .input('Phone',   sql.NVarChar, Phone)
            .input('Message', sql.NVarChar, smsMsg)
            .query('INSERT INTO Notifications (OrderId,Type,Phone,Message) VALUES (@OrderId,@Type,@Phone,@Message)');
 
        // ── Send SMS ──
        await sendSMS(Phone, smsMsg);
 
        // ── Send Email (যদি email দেওয়া থাকে) ──
        if (CustomerEmail) {
            await sendEmail(
                CustomerEmail,
                `✅ অর্ডার কনফার্মেশন — ShopBD #${orderId}`,
                orderEmailTemplate(
                    '✅ অর্ডার সফলভাবে দেওয়া হয়েছে!',
                    orderId, CustomerName, items,
                    Math.round(subTotal), deliveryCharge, Math.round(total),
                    PaymentMethod, 'Pending',
                    'আপনার অর্ডার আমরা পেয়েছি। শীঘ্রই কনফার্ম করা হবে।'
                )
            );
        }
 
        res.status(201).json({
            message: 'Order placed!',
            orderId, subTotal, deliveryCharge, total,
            estimatedDelivery: estimated.toISOString().split('T')[0]
        });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});
 
// ── GET /api/orders — admin all orders ───────────────────────
router.get('/', async (req, res) => {
    try {
        const pool = await poolPromise;
        const result = await pool.request().query(`
            SELECT o.*,
                   dp.Name    AS DeliveryPersonName,
                   dp.Phone   AS DeliveryPersonPhone,
                   dp.Vehicle AS DeliveryPersonVehicle,
                   dp.Photo   AS DeliveryPersonPhoto
            FROM Orders o
            LEFT JOIN DeliveryPersons dp ON o.DeliveryPersonId = dp.Id
            ORDER BY o.CreatedAt DESC
        `);
        res.json(result.recordset);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});
 
// ── GET /api/orders/:id — single order with tracking ─────────
router.get('/:id', async (req, res) => {
    try {
        const pool = await poolPromise;
        const orderRes = await pool.request()
            .input('id', sql.Int, req.params.id)
            .query(`
                SELECT o.*,
                       dp.Name    AS DeliveryPersonName,
                       dp.Phone   AS DeliveryPersonPhone,
                       dp.NID     AS DeliveryPersonNID,
                       dp.Vehicle AS DeliveryPersonVehicle,
                       dp.Photo   AS DeliveryPersonPhoto
                FROM Orders o
                LEFT JOIN DeliveryPersons dp ON o.DeliveryPersonId = dp.Id
                WHERE o.Id = @id
            `);
        if (!orderRes.recordset.length)
            return res.status(404).json({ error: 'Order not found' });
 
        const trackRes = await pool.request()
            .input('id', sql.Int, req.params.id)
            .query('SELECT * FROM OrderTracking WHERE OrderId=@id ORDER BY CreatedAt ASC');
 
        const itemsRes = await pool.request()
            .input('id', sql.Int, req.params.id)
            .query(`
                SELECT oi.*, p.Name, p.Emoji
                FROM OrderItems oi
                JOIN Products p ON oi.ProductId = p.Id
                WHERE oi.OrderId = @id
            `);
 
        res.json({
            order: orderRes.recordset[0],
            tracking: trackRes.recordset,
            items: itemsRes.recordset
        });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});
 
// ── PUT /api/orders/:id/status — status update (admin) ───────
const STATUS_MESSAGES = {
    'Confirmed':  'আপনার অর্ডার কনফার্ম হয়েছে! আমরা প্রস্তুতি নিচ্ছি।',
    'Processing': 'আপনার অর্ডার প্যাকিং হচ্ছে।',
    'Shipped':    'আপনার অর্ডার রওনা দিয়েছে! ডেলিভারি ম্যান শীঘ্রই পৌঁছাবেন।',
    'Delivered':  'অর্ডার ডেলিভারি সম্পন্ন! ধন্যবাদ ShopBD ব্যবহার করার জন্য।',
    'Cancelled':  'আপনার অর্ডার বাতিল করা হয়েছে।'
};
 
router.put('/:id/status', async (req, res) => {
    const { status, deliveryPersonId, deliveryNote } = req.body;
    try {
        const pool = await poolPromise;
 
        const orderRes = await pool.request()
            .input('id', sql.Int, req.params.id)
            .query('SELECT Phone, CustomerName FROM Orders WHERE Id=@id');
        const order = orderRes.recordset[0];
        if (!order) return res.status(404).json({ error: 'Order not found' });
 
        // Update order
        const req2 = pool.request()
            .input('id',        sql.Int,      req.params.id)
            .input('status',    sql.NVarChar, status)
            .input('updatedAt', sql.DateTime, new Date());
 
        let query = 'UPDATE Orders SET Status=@status, UpdatedAt=@updatedAt';
        if (deliveryPersonId) {
            req2.input('dpId', sql.Int, deliveryPersonId);
            query += ', DeliveryPersonId=@dpId';
        }
        if (deliveryNote) {
            req2.input('note', sql.NVarChar, deliveryNote);
            query += ', DeliveryNote=@note';
        }
        query += ' WHERE Id=@id';
        await req2.query(query);
 
        // Insert tracking
        const msg = STATUS_MESSAGES[status] || `Status updated to ${status}`;
        await pool.request()
            .input('OrderId', sql.Int,     req.params.id)
            .input('Status',  sql.NVarChar, status)
            .input('Message', sql.NVarChar, msg)
            .query('INSERT INTO OrderTracking (OrderId,Status,Message) VALUES (@OrderId,@Status,@Message)');
 
        // Log notification
        const notifType = status === 'Confirmed' ? 'order_confirmed'
                        : status === 'Shipped'   ? 'order_shipped'
                        : status === 'Delivered' ? 'order_delivered'
                        : 'status_update';
 
        const smsMsg = `ShopBD: অর্ডার #${req.params.id} — ${msg}`;
        await pool.request()
            .input('OrderId', sql.Int,     req.params.id)
            .input('Type',    sql.NVarChar, notifType)
            .input('Phone',   sql.NVarChar, order.Phone)
            .input('Message', sql.NVarChar, smsMsg)
            .query('INSERT INTO Notifications (OrderId,Type,Phone,Message) VALUES (@OrderId,@Type,@Phone,@Message)');
 
        // ── Send SMS ──
        await sendSMS(order.Phone, smsMsg);
 
        res.json({ message: 'Status updated', notificationSent: true });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});
 
// ── GET /api/orders/meta/delivery-persons ────────────────────
router.get('/meta/delivery-persons', async (req, res) => {
    try {
        const pool = await poolPromise;
        const result = await pool.request()
            .query('SELECT * FROM DeliveryPersons WHERE IsActive=1');
        res.json(result.recordset);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});
 
module.exports = router;