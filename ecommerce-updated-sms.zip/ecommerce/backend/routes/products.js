const express = require('express');
const router = express.Router();
const { sql, poolPromise } = require('../db');

// GET /api/products — সব product
router.get('/', async (req, res) => {
    try {
        const pool = await poolPromise;
        const result = await pool.request().query('SELECT * FROM Products ORDER BY Id DESC');
        res.json(result.recordset);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// GET /api/products/:id — একটি product
router.get('/:id', async (req, res) => {
    try {
        const pool = await poolPromise;
        const result = await pool.request()
            .input('id', sql.Int, req.params.id)
            .query('SELECT * FROM Products WHERE Id = @id');
        if (!result.recordset[0]) return res.status(404).json({ error: 'Product not found' });
        res.json(result.recordset[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// POST /api/products — নতুন product add
router.post('/', async (req, res) => {
    const { Name, Category, Price, Stock, Description, Emoji } = req.body;
    if (!Name || !Category || !Price) {
        return res.status(400).json({ error: 'Name, Category, Price required' });
    }
    try {
        const pool = await poolPromise;
        const result = await pool.request()
            .input('Name',        sql.NVarChar, Name)
            .input('Category',    sql.NVarChar, Category)
            .input('Price',       sql.Decimal,  Price)
            .input('Stock',       sql.Int,       Stock || 0)
            .input('Description', sql.NVarChar, Description || '')
            .input('Emoji',       sql.NVarChar, Emoji || '📦')
            .query(`INSERT INTO Products (Name, Category, Price, Stock, Description, Emoji)
                    OUTPUT INSERTED.*
                    VALUES (@Name, @Category, @Price, @Stock, @Description, @Emoji)`);
        res.status(201).json(result.recordset[0]);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// PUT /api/products/:id — product update
router.put('/:id', async (req, res) => {
    const { Name, Category, Price, Stock, Description, Emoji } = req.body;
    try {
        const pool = await poolPromise;
        await pool.request()
            .input('id',          sql.Int,       req.params.id)
            .input('Name',        sql.NVarChar, Name)
            .input('Category',    sql.NVarChar, Category)
            .input('Price',       sql.Decimal,  Price)
            .input('Stock',       sql.Int,       Stock)
            .input('Description', sql.NVarChar, Description || '')
            .input('Emoji',       sql.NVarChar, Emoji || '📦')
            .query(`UPDATE Products SET
                        Name=@Name, Category=@Category, Price=@Price,
                        Stock=@Stock, Description=@Description, Emoji=@Emoji
                    WHERE Id=@id`);
        res.json({ message: 'Product updated' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// DELETE /api/products/:id — product delete
router.delete('/:id', async (req, res) => {
    try {
        const pool = await poolPromise;
        await pool.request()
            .input('id', sql.Int, req.params.id)
            .query('DELETE FROM Products WHERE Id = @id');
        res.json({ message: 'Product deleted' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

module.exports = router;
