const express = require('express');
const cors    = require('cors');
const path    = require('path');

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Frontend files serve করা
app.use(express.static(path.join(__dirname, '../frontend')));

// API Routes
app.use('/api/products', require('./routes/products'));
app.use('/api/orders',   require('./routes/orders'));

// Frontend pages
app.get('/',       (req, res) => res.sendFile(path.join(__dirname, '../frontend/index.html')));
app.get('/admin',  (req, res) => res.sendFile(path.join(__dirname, '../frontend/admin.html')));

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`\n🚀 Server running at http://localhost:${PORT}`);
    console.log(`🛍️  Shop:  http://localhost:${PORT}`);
    console.log(`⚙️  Admin: http://localhost:${PORT}/admin\n`);
});
