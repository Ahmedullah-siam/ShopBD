const API = 'http://localhost:3000/api';
let editingId = null;

// ── Init ──────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
    loadStats();
    loadProducts();
    loadOrders();
});

// ── Stats ─────────────────────────────────────────
async function loadStats() {
    try {
        const [prodRes, orderRes] = await Promise.all([
            fetch(`${API}/products`),
            fetch(`${API}/orders`)
        ]);
        const products = await prodRes.json();
        const orders   = await orderRes.json();
        const revenue  = orders.reduce((a, o) => a + Number(o.TotalAmount), 0);

        document.getElementById('statProducts').textContent = products.length;
        document.getElementById('statOrders').textContent   = orders.length;
        document.getElementById('statRevenue').textContent  = '৳' + Math.round(revenue).toLocaleString();
        document.getElementById('statPending').textContent  = orders.filter(o => o.Status === 'Pending').length;
    } catch {
        console.error('Stats load failed');
    }
}

// ── Products ──────────────────────────────────────
async function loadProducts() {
    const tbody = document.getElementById('productTableBody');
    tbody.innerHTML = '<tr><td colspan="6" class="loading">Loading...</td></tr>';
    try {
        const res      = await fetch(`${API}/products`);
        const products = await res.json();

        if (!products.length) {
            tbody.innerHTML = '<tr><td colspan="6" class="loading">কোনো product নেই</td></tr>';
            return;
        }
        tbody.innerHTML = products.map(p => `
            <tr>
                <td>${p.Emoji || '📦'} ${p.Name}</td>
                <td>${p.Category}</td>
                <td>৳${Number(p.Price).toLocaleString()}</td>
                <td>${p.Stock}</td>
                <td>${p.Description || '—'}</td>
                <td>
                    <button class="btn-edit"   onclick="editProduct(${p.Id})">Edit</button>
                    <button class="btn-delete" onclick="deleteProduct(${p.Id}, '${p.Name}')">Delete</button>
                </td>
            </tr>
        `).join('');
    } catch {
        tbody.innerHTML = '<tr><td colspan="6" class="loading">Server সংযুক্ত করুন</td></tr>';
    }
}

// Add / Edit product
function openProductModal(id = null) {
    editingId = id;
    document.getElementById('modalTitle').textContent = id ? 'Product Edit' : 'নতুন Product';
    document.getElementById('productModal').classList.add('open');
    if (!id) clearProductForm();
}

function closeProductModal() {
    document.getElementById('productModal').classList.remove('open');
    editingId = null;
}

function clearProductForm() {
    ['pName','pCategory','pPrice','pStock','pDesc','pEmoji'].forEach(id => {
        document.getElementById(id).value = '';
    });
}

async function editProduct(id) {
    try {
        const res = await fetch(`${API}/products/${id}`);
        const p   = await res.json();
        document.getElementById('pName').value     = p.Name;
        document.getElementById('pCategory').value = p.Category;
        document.getElementById('pPrice').value    = p.Price;
        document.getElementById('pStock').value    = p.Stock;
        document.getElementById('pDesc').value     = p.Description || '';
        document.getElementById('pEmoji').value    = p.Emoji || '';
        openProductModal(id);
    } catch {
        alert('Product load করতে সমস্যা হয়েছে');
    }
}

async function saveProduct() {
    const data = {
        Name:        document.getElementById('pName').value.trim(),
        Category:    document.getElementById('pCategory').value.trim(),
        Price:       parseFloat(document.getElementById('pPrice').value),
        Stock:       parseInt(document.getElementById('pStock').value) || 0,
        Description: document.getElementById('pDesc').value.trim(),
        Emoji:       document.getElementById('pEmoji').value.trim() || '📦'
    };
    if (!data.Name || !data.Category || !data.Price) {
        alert('নাম, Category এবং Price দিন');
        return;
    }

    const url    = editingId ? `${API}/products/${editingId}` : `${API}/products`;
    const method = editingId ? 'PUT' : 'POST';

    try {
        await fetch(url, {
            method,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        closeProductModal();
        loadProducts();
        loadStats();
    } catch {
        alert('Save করতে সমস্যা হয়েছে');
    }
}

async function deleteProduct(id, name) {
    if (!confirm(`"${name}" delete করবেন?`)) return;
    try {
        await fetch(`${API}/products/${id}`, { method: 'DELETE' });
        loadProducts();
        loadStats();
    } catch {
        alert('Delete করতে সমস্যা হয়েছে');
    }
}

// ── Orders ────────────────────────────────────────
let deliveryPersonsList = [];

async function loadOrders() {
    const tbody = document.getElementById('orderTableBody');
    tbody.innerHTML = '<tr><td colspan="7" class="loading">Loading...</td></tr>';
    try {
        const [ordRes, dpRes] = await Promise.all([
            fetch(`${API}/orders`),
            fetch(`${API}/orders/meta/delivery-persons`)
        ]);
        const orders = await ordRes.json();
        deliveryPersonsList = await dpRes.json().catch(() => []);

        if (!orders.length) {
            tbody.innerHTML = '<tr><td colspan="7" class="loading">কোনো order নেই</td></tr>';
            return;
        }

        const dpOptions = deliveryPersonsList.map(dp =>
            `<option value="${dp.Id}">${dp.Photo} ${dp.Name}</option>`
        ).join('');

        tbody.innerHTML = orders.map(o => {
            const payBadge = o.PaymentStatus === 'Paid'
                ? '<span class="badge badge-paid">✅ Paid</span>'
                : '<span class="badge badge-pending">⏳ Pending</span>';
            const dmInfo = o.DeliveryPersonName
                ? `<br><small style="color:#6c63ff">${o.DeliveryPersonPhoto||'🛵'} ${o.DeliveryPersonName}</small>`
                : '';

            return `
            <tr>
                <td>#${o.Id}</td>
                <td>${o.CustomerName}<br><small>${o.Phone}</small></td>
                <td>
                    <small>৳${Math.round(o.SubTotal||0).toLocaleString()} + ৳${o.DeliveryCharge||0}</small><br>
                    <strong>৳${Math.round(o.TotalAmount).toLocaleString()}</strong>
                </td>
                <td>${o.PaymentMethod}<br>${payBadge}</td>
                <td>
                    <span class="badge badge-${o.Status.toLowerCase()}">${o.Status}</span>
                    ${dmInfo}
                </td>
                <td>
                    <select id="status_${o.Id}" style="font-size:12px;padding:4px;border:1px solid #ddd;border-radius:5px;margin-bottom:4px;width:100%">
                        <option ${o.Status==='Pending'    ?'selected':''}>Pending</option>
                        <option ${o.Status==='Confirmed'  ?'selected':''}>Confirmed</option>
                        <option ${o.Status==='Processing' ?'selected':''}>Processing</option>
                        <option ${o.Status==='Shipped'    ?'selected':''}>Shipped</option>
                        <option ${o.Status==='Delivered'  ?'selected':''}>Delivered</option>
                        <option ${o.Status==='Cancelled'  ?'selected':''}>Cancelled</option>
                    </select>
                    <select id="dp_${o.Id}" style="font-size:12px;padding:4px;border:1px solid #ddd;border-radius:5px;margin-bottom:4px;width:100%">
                        <option value="">— Delivery Man —</option>
                        ${dpOptions}
                    </select>
                    <button onclick="updateStatus(${o.Id})" style="width:100%;padding:5px 0;background:#6c63ff;color:#fff;border:none;border-radius:6px;cursor:pointer;font-size:12px">
                        আপডেট করুন
                    </button>
                </td>
            </tr>`;
        }).join('');
    } catch (e) {
        tbody.innerHTML = '<tr><td colspan="7" class="loading">Server সংযুক্ত করুন</td></tr>';
    }
}

async function updateStatus(id) {
    const status = document.getElementById('status_' + id).value;
    const dpEl   = document.getElementById('dp_' + id);
    const deliveryPersonId = dpEl?.value ? parseInt(dpEl.value) : null;
    try {
        const res = await fetch(`${API}/orders/${id}/status`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ status, deliveryPersonId })
        });
        const data = await res.json();
        if (res.ok) {
            const notif = data.notificationSent ? ' | 📱 SMS পাঠানো হয়েছে' : '';
            alert(`✅ Status "${status}" করা হয়েছে${notif}`);
            loadOrders();
            loadStats();
        }
    } catch {
        alert('Status update করতে সমস্যা হয়েছে');
    }
}
