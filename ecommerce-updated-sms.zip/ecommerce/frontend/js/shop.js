const API = 'http://localhost:3000/api';

let allProducts = [];
let cart = {};
let currentCat = 'All';
let selectedPayment = 'COD';
let deliveryCharge = 60;

// ── OTP system ──────────────────────────────────────
let generatedOTP = '';
let otpVerified  = false;

function sendOTP() {
    const phone = document.getElementById('payPhone').value.trim();
    if (!phone || phone.length < 11) { showToast('সঠিক নম্বর দিন'); return; }

    // Generate 6-digit OTP
    generatedOTP = Math.floor(100000 + Math.random() * 900000).toString();
    otpVerified  = false;

    // Show OTP field
    document.getElementById('otpField').style.display = 'block';
    document.getElementById('otpStatus').textContent = '';

    // Send OTP via backend
    fetch(`${API}/orders/send-otp`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone, otp: generatedOTP, method: selectedPayment })
    }).then(() => {
        showToast(`OTP পাঠানো হয়েছে ${phone} নম্বরে`);
    }).catch(() => {
        // Even if SMS fails, OTP is still usable (shown in console for dev)
        console.log('DEV OTP:', generatedOTP);
        showToast(`OTP পাঠানো হয়েছে ${phone} নম্বরে`);
    });
}

function verifyOTP() {
    const entered = document.getElementById('payOTP').value.trim();
    const status  = document.getElementById('otpStatus');
    if (entered === generatedOTP) {
        otpVerified = true;
        status.style.color = '#28a745';
        status.textContent = '✅ OTP যাচাই সম্পন্ন! এখন পাসওয়ার্ড দিয়ে পেমেন্ট করুন।';
        document.getElementById('trxnField').style.display = 'block';
    } else {
        status.style.color = '#dc3545';
        status.textContent = '❌ ভুল OTP। আবার চেষ্টা করুন।';
    }
}

// ── Init ──────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
    loadProducts();
});

async function loadProducts() {
    try {
        const res = await fetch(`${API}/products`);
        allProducts = await res.json();
        renderProducts();
    } catch {
        document.getElementById('productsGrid').innerHTML =
            '<p style="padding:20px;color:#999">Server connect করুন: npm start</p>';
    }
}

// ── Products ──────────────────────────────────────
function renderProducts() {
    const query = document.getElementById('searchInput').value.toLowerCase();
    const grid  = document.getElementById('productsGrid');
    const filtered = allProducts.filter(p => {
        const matchCat    = currentCat === 'All' || p.Category === currentCat;
        const matchSearch = p.Name.toLowerCase().includes(query) || p.Category.toLowerCase().includes(query);
        return matchCat && matchSearch;
    });
    if (!filtered.length) {
        grid.innerHTML = '<p style="padding:20px;color:#999">কোনো product পাওয়া যায়নি</p>';
        return;
    }
    grid.innerHTML = filtered.map(p => `
        <div class="product-card">
            <div class="prod-img">${p.Emoji || '📦'}</div>
            <div class="prod-info">
                <div class="prod-name">${p.Name}</div>
                <div class="prod-cat">${p.Category}</div>
                <div class="prod-footer">
                    <span class="prod-price">৳${Number(p.Price).toLocaleString()}</span>
                    <button class="add-btn" onclick="addToCart(${p.Id}, '${p.Name}', ${p.Price}, '${p.Emoji || '📦'}')">
                        + Add
                    </button>
                </div>
            </div>
        </div>
    `).join('');
}

function setCategory(cat, btn) {
    currentCat = cat;
    document.querySelectorAll('.cat-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    renderProducts();
}

// ── Cart ──────────────────────────────────────────
function addToCart(id, name, price, emoji) {
    if (!cart[id]) cart[id] = { id, name, price, emoji, qty: 0 };
    cart[id].qty++;
    updateCartCount();
    renderCartItems();
    showToast(`${name} cart-এ যোগ হয়েছে!`);
}

function changeQty(id, delta) {
    if (!cart[id]) return;
    cart[id].qty += delta;
    if (cart[id].qty <= 0) delete cart[id];
    updateCartCount();
    renderCartItems();
}

function updateCartCount() {
    const total = Object.values(cart).reduce((a, b) => a + b.qty, 0);
    document.getElementById('cartCount').textContent = total;
}

function renderCartItems() {
    const body  = document.getElementById('cartBody');
    const foot  = document.getElementById('cartFoot');
    const items = Object.values(cart);
    if (!items.length) {
        body.innerHTML = '<div class="empty-msg">Cart খালি আছে</div>';
        foot.style.display = 'none';
        return;
    }
    foot.style.display = 'block';
    let subTotal = 0;
    body.innerHTML = items.map(item => {
        subTotal += item.price * item.qty;
        return `
        <div class="cart-item">
            <div class="ci-emoji">${item.emoji}</div>
            <div class="ci-info">
                <div class="ci-name">${item.name}</div>
                <div class="ci-price">৳${Number(item.price).toLocaleString()}</div>
                <div class="qty-row">
                    <button class="qty-btn" onclick="changeQty(${item.id}, -1)">−</button>
                    <span class="qty-val">${item.qty}</span>
                    <button class="qty-btn" onclick="changeQty(${item.id}, 1)">+</button>
                </div>
            </div>
            <button class="remove-btn" onclick="changeQty(${item.id}, -99)" title="Remove">✕</button>
        </div>`;
    }).join('');
    document.getElementById('cartSubtotal').textContent = '৳' + Math.round(subTotal).toLocaleString();
    document.getElementById('cartDelivery').textContent = '৳' + deliveryCharge;
    document.getElementById('cartTotal').textContent    = '৳' + (Math.round(subTotal) + deliveryCharge).toLocaleString();
}

function toggleCart() {
    document.getElementById('cartPanel').classList.toggle('open');
    document.getElementById('cartOverlay').classList.toggle('open');
    renderCartItems();
}

// ── Delivery Charge fetch ────────────────────────────────────────
async function updateDeliveryCharge() {
    const city = document.getElementById('cCity').value.trim();
    if (!city) { deliveryCharge = 60; updateCheckoutSummary(); return; }
    try {
        const res = await fetch(`${API}/orders/delivery-charge?city=${encodeURIComponent(city)}`);
        const data = await res.json();
        deliveryCharge = data.charge;
    } catch { deliveryCharge = 150; }
    updateCheckoutSummary();
}

function updateCheckoutSummary() {
    const subTotal = Object.values(cart).reduce((a, b) => a + b.price * b.qty, 0);
    const total    = subTotal + deliveryCharge;
    document.getElementById('sumSubtotal').textContent   = '৳' + Math.round(subTotal).toLocaleString();
    document.getElementById('sumDelivery').textContent   = '৳' + deliveryCharge;
    document.getElementById('sumTotal').textContent      = '৳' + Math.round(total).toLocaleString();
}

// ── Payment selection ────────────────────────────────────────────
function selectPayment(method) {
    selectedPayment = method;
    document.querySelectorAll('.pay-option').forEach(el => el.classList.remove('active'));
    document.getElementById('pay_' + method).classList.add('active');

    // Show/hide mobile number & trxn field
    const mobileFields = document.getElementById('mobilePayFields');
    const cardFields   = document.getElementById('cardPayFields');
    mobileFields.style.display = (method === 'bKash' || method === 'Nagad') ? 'block' : 'none';
    cardFields.style.display   = (method === 'Card') ? 'block' : 'none';

    // Reset OTP state
    if (method === 'bKash' || method === 'Nagad') {
        document.getElementById('otpField').style.display = 'none';
        document.getElementById('trxnField').style.display = 'none';
        document.getElementById('otpStatus').textContent = '';
        otpVerified = false;
        generatedOTP = '';
    }

    // Update label and target number
    const labels = { bKash: '🟣 bKash', Nagad: '🟠 Nagad', Card: '💳 Card', COD: '💵 Cash on Delivery' };
    document.getElementById('payMethodLabel').textContent = labels[method] || method;

    // Update owner payment number display
    const ownerNum = document.getElementById('payTargetNumber');
    if (ownerNum) ownerNum.textContent = '01771484565';
}

// ── Checkout modal ────────────────────────────────────────────────
function openCheckout() {
    document.getElementById('checkoutModal').classList.add('open');
    document.getElementById('checkoutForm').style.display = 'block';
    document.getElementById('orderSuccess').style.display = 'none';
    selectPayment('COD');
    updateCheckoutSummary();
}
function closeCheckout() {
    document.getElementById('checkoutModal').classList.remove('open');
}

async function placeOrder() {
    const name    = document.getElementById('cName').value.trim();
    const phone   = document.getElementById('cPhone').value.trim();
    const address = document.getElementById('cAddress').value.trim();
    const city    = document.getElementById('cCity').value.trim();
    const postal  = document.getElementById('cPost').value.trim();

    if (!name || !phone || !address) { showToast('নাম, ফোন ও ঠিকানা দিন'); return; }

    // Payment validation
    let transactionId = '';
    let paymentPhone  = '';

    if (selectedPayment === 'bKash' || selectedPayment === 'Nagad') {
        paymentPhone  = document.getElementById('payPhone').value.trim();
        transactionId = document.getElementById('payTrxn') ? document.getElementById('payTrxn').value.trim() : '';
        if (!paymentPhone) {
            showToast(`${selectedPayment} নম্বর দিন`);
            return;
        }
        if (!otpVerified) {
            showToast('আগে OTP যাচাই করুন');
            return;
        }
        if (!transactionId) {
            showToast('Transaction ID দিন');
            return;
        }
    }
    if (selectedPayment === 'Card') {
        transactionId = document.getElementById('cardTrxn').value.trim();
        if (!transactionId) { showToast('Card Transaction ID দিন'); return; }
    }

    const items = Object.values(cart).map(c => ({ productId: c.id, quantity: c.qty }));

    try {
        document.getElementById('placeOrderBtn').disabled = true;
        document.getElementById('placeOrderBtn').textContent = 'অপেক্ষা করুন...';

        const res = await fetch(`${API}/orders`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                CustomerName: name, Phone: phone, Address: address,
                City: city, PostalCode: postal, items,
                PaymentMethod: selectedPayment,
                TransactionId: transactionId,
                PaymentPhone: paymentPhone
            })
        });
        const data = await res.json();
        if (res.ok) {
            // Show success screen
            document.getElementById('checkoutForm').style.display = 'none';
            document.getElementById('orderSuccess').style.display = 'block';
            document.getElementById('orderIdText').textContent        = data.orderId;
            document.getElementById('successSubtotal').textContent    = '৳' + Math.round(data.subTotal).toLocaleString();
            document.getElementById('successDelivery').textContent    = '৳' + data.deliveryCharge;
            document.getElementById('successTotal').textContent       = '৳' + Math.round(data.total).toLocaleString();
            document.getElementById('successPayMethod').textContent   = selectedPayment;
            document.getElementById('successEstimated').textContent   = data.estimatedDelivery;
            // Reset OTP state
            otpVerified = false; generatedOTP = '';
            showToast(`✅ অর্ডার #${data.orderId} সফল হয়েছে!`);
        } else {
            showToast('Order দিতে সমস্যা হয়েছে: ' + (data.error || ''));
        }
    } catch {
        showToast('Server সংযোগ করুন');
    } finally {
        const btn = document.getElementById('placeOrderBtn');
        if (btn) { btn.disabled = false; btn.textContent = 'Order দিন ✓'; }
    }
}

function finishOrder() {
    cart = {};
    updateCartCount();
    toggleCart();
    closeCheckout();
    ['cName','cPhone','cAddress','cCity','cPost','payPhone','payTrxn','cardTrxn']
        .forEach(id => { const el = document.getElementById(id); if (el) el.value = ''; });
}

// ── Order Tracking ────────────────────────────────────────────────
function openTracking() {
    document.getElementById('trackingModal').classList.add('open');
    document.getElementById('trackResult').innerHTML = '';
    document.getElementById('trackInput').value = '';
}
function closeTracking() {
    document.getElementById('trackingModal').classList.remove('open');
}

async function searchOrder() {
    const orderId = document.getElementById('trackInput').value.trim();
    if (!orderId) { showToast('Order ID দিন'); return; }
    const resultDiv = document.getElementById('trackResult');
    resultDiv.innerHTML = '<p style="color:#888">খোঁজা হচ্ছে...</p>';
    try {
        const res = await fetch(`${API}/orders/${orderId}`);
        const data = await res.json();
        if (!res.ok) { resultDiv.innerHTML = '<p style="color:red">Order পাওয়া যায়নি</p>'; return; }

        const { order, tracking, items } = data;

        const statusIcon = {
            'Pending':    '⏳', 'Confirmed': '✅', 'Processing': '📦',
            'Shipped':    '🚚', 'Delivered': '🎉', 'Cancelled':  '❌'
        };

        const deliveryHtml = order.DeliveryPersonName ? `
            <div class="delivery-man-box">
                <div class="dm-title">🛵 ডেলিভারি ম্যান</div>
                <div class="dm-row">
                    <span class="dm-photo">${order.DeliveryPersonPhoto || '🛵'}</span>
                    <div>
                        <div class="dm-name">${order.DeliveryPersonName}</div>
                        <div class="dm-info">📞 ${order.DeliveryPersonPhone}</div>
                        <div class="dm-info">🚗 ${order.DeliveryPersonVehicle || ''}</div>
                    </div>
                </div>
            </div>` : '';

        const trackHtml = tracking.map(t => `
            <div class="track-step ${t.Status === order.Status ? 'active' : ''}">
                <div class="track-dot">${statusIcon[t.Status] || '●'}</div>
                <div class="track-info">
                    <div class="track-status">${t.Status}</div>
                    <div class="track-msg">${t.Message}</div>
                    <div class="track-time">${new Date(t.CreatedAt).toLocaleString('bn-BD')}</div>
                </div>
            </div>
        `).join('');

        const itemsHtml = items.map(i =>
            `<div class="ord-item">${i.Emoji} ${i.Name} × ${i.Quantity} = ৳${Math.round(i.Price * i.Quantity).toLocaleString()}</div>`
        ).join('');

        resultDiv.innerHTML = `
            <div class="track-card">
                <div class="track-header">
                    <div>
                        <div class="track-id">অর্ডার #${order.Id}</div>
                        <div class="track-customer">${order.CustomerName} | ${order.Phone}</div>
                    </div>
                    <div class="status-badge status-${order.Status.toLowerCase()}">${statusIcon[order.Status] || ''} ${order.Status}</div>
                </div>
                <div class="track-items">${itemsHtml}</div>
                <div class="track-price-row">
                    <span>পণ্য মূল্য: ৳${Math.round(order.SubTotal).toLocaleString()}</span>
                    <span>ডেলিভারি: ৳${order.DeliveryCharge}</span>
                    <strong>মোট: ৳${Math.round(order.TotalAmount).toLocaleString()}</strong>
                </div>
                <div class="track-pay-row">
                    💳 ${order.PaymentMethod} |
                    ${order.PaymentStatus === 'Paid' ? '✅ পেমেন্ট সম্পন্ন' : '⏳ পেমেন্ট বাকি'}
                    ${order.EstimatedDelivery ? ` | 📅 আনুমানিক: ${order.EstimatedDelivery.split('T')[0]}` : ''}
                </div>
                ${deliveryHtml}
                <div class="track-timeline">${trackHtml}</div>
            </div>
        `;
    } catch {
        resultDiv.innerHTML = '<p style="color:red">সংযোগ সমস্যা</p>';
    }
}

// ── Toast ─────────────────────────────────────────
function showToast(msg) {
    const t = document.getElementById('toast');
    t.textContent = msg;
    t.classList.add('show');
    setTimeout(() => t.classList.remove('show'), 2500);
}
